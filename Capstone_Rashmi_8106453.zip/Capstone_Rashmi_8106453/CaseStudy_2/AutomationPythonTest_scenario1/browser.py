import pytest
from selenium import webdriver
# from webdrivermanager.edge import EdgeDriverManager


@pytest.fixture(scope="session")
def browser():
    driver = webdriver.Edge()
    driver.maximize_window()
    yield driver
    driver.quit()

