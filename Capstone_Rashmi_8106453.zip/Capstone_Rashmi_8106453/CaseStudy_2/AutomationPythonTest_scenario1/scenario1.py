import time

from selenium.webdriver.common.by import By
from browser import browser

def test_title(browser):
    browser.get("https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/")
    assert browser.title == "Want to practice test automation? Try these demo sites! | Automation Panda"


def test_speaking_page(browser):
    browser.get("https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/")
    speaking = browser.find_element(By.CSS_SELECTOR, "div.menu-primary-container>ul>li:nth-of-type(4)")
    speaking.click()
    assert browser.title == "Speaking | Automation Panda"
    browser.execute_script('window.scrollTo(0,600)', '')
    time.sleep(5)
    keynote = browser.find_element(By.CSS_SELECTOR, "div.entry-content>h2:first-of-type")
    assert keynote.is_displayed()
    keynotetext = browser.find_element(By.CSS_SELECTOR, "figure.wp-block-table.is-style-stripes").text
    if keynotetext:
        print(keynotetext)
    else:
        print("Keynote address not have any text.")
        browser.execute_script('window.scrollTo(1000,1450)')
        time.sleep(5)
        conference_talks = browser.find_element(By.CSS_SELECTOR, "div.entry-content>h2:nth-of-type(2)")
        assert conference_talks.is_displayed()
        conference_text = browser.find_element(By.CSS_SELECTOR, "figure.wp-block-table.is-style-stripes").text
        if conference_text:
            print(conference_text)
        else:
            print("Conference talks not have any text.")
