import pytest as pytest
from selenium import webdriver
# from webdrivermanager.gecko import FirefoxDriverManager


@pytest.fixture(scope="session")
def browser():
    driver = webdriver.Firefox()
    driver.maximize_window()
    yield driver
    driver.quit()
