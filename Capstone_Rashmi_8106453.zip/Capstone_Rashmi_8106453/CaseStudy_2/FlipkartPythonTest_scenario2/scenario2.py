import time
from selenium.webdriver.common.by import By
from browser import browser

def test_popup(browser):
    browser.get("https://www.flipkart.com/")
    pop_up = browser.find_element(By.CSS_SELECTOR, "div._3wFoIb.row")
    pop_up_close_but = browser.find_element(By.CSS_SELECTOR, "button._2KpZ6l._2doB4z")
    time.sleep(5)
    if pop_up.is_displayed():
        pop_up_close_but.click()
    else:
        print("Pop up is not there or its closed")


def test_verify_login(browser):
    login_button = browser.find_element(By.CSS_SELECTOR, "a._1_3w1N")
    assert login_button.is_displayed()


def test_login(browser):
    login_button = browser.find_element(By.CSS_SELECTOR, "a._1_3w1N")
    login_button.click()
    time.sleep(3)
    mobile_number = browser.find_element(By.CSS_SELECTOR, "input._2IX_2-.VJZDxU")
    mobile_number.send_keys("8792430757")
    time.sleep(3)
    otp_button = browser.find_element(By.XPATH, "//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")
    otp_button.click()
    time.sleep(5)
    message = browser.find_element(By.XPATH, "//div[contains(text(), 'Please enter the OTP sent to')]")
    assert message.is_displayed()